import { ReactNode } from "react";

export type FCC = ({ children: ReactNode }) => ReactNode;

export type RegisterUser = {
    name: {
        first: string;
        middle?: string;
        last: string;
    };
    email: string;
    password: string;
    phone: string;
    image?: {
        url?: string;
        alt?: string;
    };
    address: {
        state?: string;
        country: string;
        city: string;
        street: string;
        houseNumber: number;
        zip?: number;
    };
    isBusiness: boolean;
};

export type LoginUser = {
    email: string;
    password: string;
}

export type CardType = {
    _id: string;
    title: string;
    subtitle: string;
    description: string;
    phone: string;
    email: string;
    web: string;
    image: {
        url: string;
        alt: string;
        _id: string;
    };
    address: {
        state: string;
        country: string;
        city: string;
        street: string;
        houseNumber: string;
        zip: number;
        _id: string;
    }
    bizNumber: number;
    likes: string[];
    user_id: string;
    createdAt: string;
    __v: number;
};

export type ErrorType = {
    status: number;
    message: string;
    details: string;
};

export interface CardData {
    _id: string;
    title: string; // required, min length 2, max length 256
    subtitle: string; // required, min length 2, max length 256
    description: string; // required, min length 2, max length 1024
    phone: string; // required, min length 9, max length 11
    email: string; // required, min length 5
    web: string; // optional, min length 14
    image: { // required
        url: string; // min length 14
        alt: string; // min length 2, max length 256
    };
    address: { // required
        state: string; // optional
        country: string; // required
        city: string; // required
        street: string; // required
        houseNumber: string; // required
        zip: number; // optional
    };
}

export type FavoriteCard = {
    cardId: string,
    isFavorite: boolean,
    token: string;
    onToggleF: (cardId: string) => void;
}

export interface Card {
    _id: string;
    title: string;
    subtitle: string;
    image: {
        url: string;
        alt: string;
    };
} 