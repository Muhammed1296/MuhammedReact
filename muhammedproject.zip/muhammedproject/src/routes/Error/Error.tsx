import { useRouteError } from "react-router-dom";
import './Error.scss';

type ErrorType = {
    status: number;
    statusText: String;
    data: String;
};

const Error = () => {
    const { data, status, statusText } = useRouteError() as ErrorType;

    return (
        <div className="error-page">
            <h1>Error</h1>
            <p>Dont panic , all can be solved</p>
            <p>{statusText}</p>
        </div>
    )
}

export default Error