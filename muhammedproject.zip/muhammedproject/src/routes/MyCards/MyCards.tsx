import React, { useEffect, useState, useContext, FC } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import FavoriteB from '../../components/Favorite/Favorite';
import { AuthContext } from '../../contexts/AuthContext'; 
import { useSearch } from '../../contexts/SearchContext'; 
import { CardType } from '../../@Types/types'; 
import Swal from 'sweetalert2';
import './MyCards.scss';
import { FaEdit, FaTrash } from 'react-icons/fa';
import { Card } from '../../@Types/types'; 
import Spinners from '../../components/Spinners/Spinners';


const MyCards: FC = () => {
    const [cards, setCards] = useState<Card[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const authContext = useContext(AuthContext);
    const token = authContext ? authContext.token : null;
    const [favorites, setFavorites] = useState<string[]>(() => JSON.parse(localStorage.getItem('favorites') || '[]'));
    const { searchTerm } = useSearch();

    useEffect(() => {
        if (!token) {
            setLoading(false);
            return;  
        }
        setLoading(true);
        axios.get('https://monkfish-app-z9uza.ondigitalocean.app/bcard2/cards/my-cards', {
            headers: { 'x-auth-token': token }
        })
            .then(response => {
                setCards(response.data);
                setLoading(false);
            })
            .catch(err => {
                setError(err.toString());
                setLoading(false);
            });
    }, [token]);

    /* const deleteCard = (cardId: string) => {
        if (window.confirm("Are you sure you want to delete this card?")) {
            axios.delete(`https://monkfish-app-z9uza.ondigitalocean.app/bcard2/cards/${cardId}`, {
                headers: { 'x-auth-token': token }
            })
                .then(() => {
                    // Remove card from state
                    setCards(cards.filter(card => card._id !== cardId));
                })
                .catch(err => {
                    console.error("Error deleting card:", err);
                });
        }
    }; */

    const deleteCard = (cardId) => {
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                axios.delete(`https://monkfish-app-z9uza.ondigitalocean.app/bcard2/cards/${cardId}`, {
                    headers: { 'x-auth-token': token }
                })
                    .then(() => {
                        setCards(cards.filter(card => card._id !== cardId)); // Update state
                        Swal.fire(
                            'Deleted!',
                            'Your card has been deleted.',
                            'success'
                        )
                    })
                    .catch(err => {
                        console.error("Error deleting card:", err);
                        Swal.fire(
                            'Failed!',
                            'There was a problem deleting your card.',
                            'error'
                        )
                    });
            }
        });
    };

    const addToFavorites = (cardId) => {
        const newFavorites = favorites.includes(cardId)
            ? favorites.filter(id => id !== cardId)  // Remove from favorites
            : [...favorites, cardId];  // Add to favorites
        setFavorites(newFavorites);
        localStorage.setItem('favorites', JSON.stringify(newFavorites));
    };

    const filteredCards = cards.filter(c => c.title.toLowerCase().includes(searchTerm.toLowerCase()));

    if (!token) return <p>Please log in to view your cards.</p>;
    if (loading) return <Spinners />;
    if (error) return <div>Error loading your cards: {error}</div>;

    // MyCards.tsx
    return (
        <div className='allCards dark:bg-gray-800'>
            {filteredCards.map((card) => ( 

                <div key={card._id} className="cardBox dark:text-white border-white">

                    <Link to={`/cards/${card._id}`} className="imgBox">
                        <img src={card.image.url} alt={card.image.alt} className="card-image" />
                    </Link>
                    <h2>{card.title}</h2>
                    <h3>{card.subtitle}</h3>
                    <FavoriteB
                        cardId={card._id}
                        isFavorite={favorites.includes(c._id)}
                        onToggleF={addToFavorites} token={""} />
                        <FaTrash onClick={()=>deleteCard(card._id)}/>

                    {/* <div className="card-actions">
                        <Link to={`/update/${card._id}`} className="card-edit-icon">
                            <FaEdit />
                        </Link>
                        <FaTrash
                            onClick={() => deleteCard(card._id)}
                            className="card-delete-icon"
                        />
                    </div>
                    <Link to={`/cards/${card._id}`} className="card-link">
                        <FavoriteB
                            cardId={card._id}
                            isFavorite={favorites.includes(card._id)}
                            onToggleF={addToFavorites} token={''} />
                        <h2 className="card-title">{card.title}</h2>
                        <hr />
                        <p className="card-subtitle">{card.subtitle}</p>
                        <img src={card.image.url} alt={card.image.alt} className="card-image" />
                    </Link> */}
                </div>
            ))}
        </div>
    );

};

export default MyCards;