import { createBrowserRouter } from "react-router-dom";
import Root from "../Layout/Root.tsx";
import Error from "./Error/Error.tsx";
import Cards from "./Cards/Cards.tsx";
import Register from "./Register/Register.tsx";
import Login from "./Login/Login.tsx";
import ProtectedRoutes from "../components/ProtectedRoutes.tsx";
import Profile from "./Profile/Profile.tsx";
import Card from "./Card/Card.tsx";
import CreateCard from "./CreateCard/CreateCard.tsx";
import MyCards from "./MyCards/MyCards.tsx";
import About from "../components/About/About.tsx";


export const router = createBrowserRouter([
    {
        path: '/',
        element: <Root />,
        errorElement: <Error />,
        children: [
            { index: true, element: <Cards /> },
            { path: '/register', element: <Register /> },
            { path: '/about', element: <About /> },
            { path: '/login', element: <Login /> },
            { path: '/cards', element: <Cards /> },
            { path: '/cards/:id', element: <Card /> },
            {
                path: '/profile', element: (
                    <ProtectedRoutes>
                        <Profile />
                    </ProtectedRoutes>
                )
            },
            {
                path: '/favorites',
                element: <Cards regularMode={false} />
            },
            {
                path: '/createCard',
                element: <CreateCard />
            },
            {
                path: '/mycards', element: <MyCards />
            }

        ]
    }
]);