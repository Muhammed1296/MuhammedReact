import { Link } from "react-router-dom";
import Spinners from "../../components/Spinners/Spinners";
import { useState, useEffect } from "react";
import FavoriteB from "../../components/Favorite/Favorite";
import axios from "axios";
import { CardType } from "../../@Types/types";
import { useSearch } from "../../contexts/SearchContext";
import { useAuth } from "../../contexts/AuthContext";
import "./Cards.scss";



const Cards = ({ regularMode = true }) => {
    // const { isLoggedIn, login, logout } = useAuth();
    const [cards, setCards] = useState<CardType[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const [favorites, setFavorites] = useState<string[]>([]);
    const { token } = useAuth();
    const { searchTerm } = useSearch();

    useEffect(() => {
        const currentFavorites = JSON.parse(localStorage.getItem("favorites") || "[]");
        setFavorites(currentFavorites);

        setLoading(true);
        axios.get("https://monkfish-app-z9uza.ondigitalocean.app/bcard2/cards", {
            headers: { 'x-auth-token': token }
        })
            .then((res) => {
                setCards(res.data);
            })
            .catch(() => setError("failed loading"))
            .finally(() => setLoading(false));
    }, []);

    const addToFavorites = (cardId) => {
        const newFavorites = favorites.includes(cardId)
            ? favorites.filter(id => id !== cardId)
            : [...favorites, cardId];
        setFavorites(newFavorites);
        localStorage.setItem('favorites', JSON.stringify(newFavorites));
    };


    const filteredCards = cards.filter(card => {
        const matchesSearchTerm = card.title.toLowerCase().includes(searchTerm.toLowerCase());
        return !regularMode
            ? matchesSearchTerm && favorites.includes(card._id)
            : matchesSearchTerm;
    })


    return (
        <div className="allCards dark:bg-gray-800">

            {loading && <Spinners />}
            {error && <div>{error}</div>}

            {filteredCards.map((c) => (
                <div key={c._id} className="cardBox dark:text-white border-white">

                    <Link to={`/cards/${c._id}`} className="imgBox">
                        <img src={c.image.url} alt={c.image.alt} className="card-image" />
                    </Link>
                  
                    <h2>{c.title}</h2>
                    <h3>{c.subtitle}</h3>
                    <hr />
                    <p>{c.address.city}</p>
                    <p>{c.address.street}</p>
                    <p>{c.phone}</p>

                    <FavoriteB
                        cardId={c._id}
                        isFavorite={favorites.includes(c._id)}
                        onToggleF={addToFavorites} token={""} />

                </div>
            ))}
        </div>
    );
};

export default Cards;