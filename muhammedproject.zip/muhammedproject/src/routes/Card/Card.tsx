import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { CardType, ErrorType } from "../../@Types/types";
import { getCardById } from "../../services/cards";
import "./Card.scss";
import { FaEnvelope, FaGlobe, FaHeart, FaPhone } from "react-icons/fa";

const Card = () => {

    // dynamic route: /cards/:id
    const { id } = useParams();
    const [card, setCard] = useState<CardType>();
    const [error, setError] = useState<ErrorType>();

    useEffect(() => {
        getCardById(id ?? "")
            .then((res) => {
                setCard(res.data);
            })
            .catch((e) => {
                const status = e.response.status;
                const message = e.message;
                const details = e.response.data;

                setError({ status, message, details });
            });
    }, []);
    return error ? (
        <div>
            <h2>{error.message}</h2>
        </div>
    ) : (
        <div className="cardP">

            <img src={card?.image.url} alt={card?.image.alt} className="card-image" />
            <h2>{card?.title}</h2>
            <h3>{card?.subtitle}</h3>
            <p>City: {card?.address.city}</p>
            <p>Street: {card?.address.city}</p>
            <p>HouseNumber: {card?.address.houseNumber}</p>
            <p>Mail: {card?.email}</p>
            <p>Phone Number: {card?.phone}</p>
            <p>Like: {card?.likes.length}</p>

        </div>

    );
}
export default Card;