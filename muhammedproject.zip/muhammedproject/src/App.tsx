import './App.scss'

function App() {

  return (
    <div>Holla Guys</div>
  )
}

export default App
