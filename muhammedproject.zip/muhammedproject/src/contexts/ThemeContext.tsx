import { createContext, useEffect, useState } from "react";


export const ThemeContext = createContext({
    theme: 'light',
    toggle: () => {}
});

export const ThemeProvider = ({ children }) => {
    useEffect(() => {
        let th = localStorage.getItem('theme') ?? "light";
        setTheme(th);
        if (th === 'dark') {
            document.body.classList.add('dark');
        }
    }, []);

    const [theme, setTheme] = useState('light');

    const toggle = () => {
        const newTheme = theme == 'light' ? 'dark' : 'light';
        localStorage.setItem('theme', newTheme);
        if (newTheme == 'dark') {
            document.body.classList.add('dark');
        } else {
            document.body.classList.remove('dark');
        }
        setTheme(newTheme);
    };

    return (
        <ThemeContext.Provider value={{ theme, toggle }}>
            {children}
        </ThemeContext.Provider>
    );
};