export const registerMock = {
    "name": {
        "first": "muhammad",
        "middle": "",
        "last": "abdo"
    },
    "phone": "0544444444",
    "email": "Muhammad@gmail.com",
    "password": "Muhammad123456",
    "image": {
        "url": "https://www.istockphoto.com/vector/blank-man-profile-head-icon-placeholder-gm1298261537-391152374",
        "alt": "Placeholder image"
    },
    "address": {
        "state": "IL",
        "country": "Israel",
        "city": "Haifa",
        "street": "Hagefen",
        "houseNumber": 2,
        "zip": 789456
    },
    "isBusiness": true
}