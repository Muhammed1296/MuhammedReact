import { FaHeart, FaRegHeart } from "react-icons/fa"
import { FavoriteCard } from "../../@Types/types";
import axios from "axios";

export const FavoriteB: React.FC<FavoriteCard> = ({ cardId, isFavorite, onToggleF, token }) => {

    const toggleFavorite = () => {
        const url = `https://monkfish-app-z9uza.ondigitalocean.app/bcard2/cards/${cardId}`;

        axios.patch(url, {}, {
            headers: { 'x-auth-token': token }
        })
            .then(() => { onToggleF(cardId); })
            .catch(er => { alert('card wasnt added to favorites') });
    }

    return (
        // <div className="favBox">
        <button className="favoriteBtn" onClick={(e) => {
            toggleFavorite();
            e.preventDefault();
            e.stopPropagation();
        }}>
            {isFavorite ? <FaHeart /> : <FaRegHeart />}
        </button>
        // </div>
    )
}

export default FavoriteB;