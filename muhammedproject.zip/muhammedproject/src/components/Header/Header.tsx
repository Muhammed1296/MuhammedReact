import { TextField } from '@mui/material';
import { useTheme } from '../../hooks/useTheme';
import NavBar from '../NavBar/NavBar';
import './Header.scss';
import Search from '../Search/Search';

const Header = () => {
    const { theme } = useTheme();
    return (
        <header className='siteH dark:bg-gray-500 dark:text-purple-400'>
            <NavBar />
        </header>
    );
}

export default Header;