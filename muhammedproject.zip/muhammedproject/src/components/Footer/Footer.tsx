import { NavLink, useNavigate } from 'react-router-dom'
import './Footer.scss'
import { useTheme } from '../../hooks/useTheme'
import { TextField } from '@mui/material';
import DarkLight from '../DarkLightMode/DarkLight';
import { useAuth } from '../../contexts/AuthContext';
import Search from '../Search/Search';

const Footer = () => {
    const { theme } = useTheme();
    const { isLoggedIn, user, logout } = useAuth();
    const navigate = useNavigate();
    return (
        <footer className=' dark:bg-gray-500 dark:text-purple-400'>
            <NavLink to='/' className='brand dark:text-purple-400'>Home</NavLink>
            <NavLink to='/about' className='brand dark:text-purple-400'>About</NavLink>

            {!isLoggedIn && <NavLink to='/register' className='brand dark:text-purple-400'>Register</NavLink>}

            {!isLoggedIn && <NavLink to='/login' className='brand dark:text-purple-400'>Login</NavLink>}

            {isLoggedIn && <NavLink to='/profile' className='brand dark:text-purple-400'>Profile</NavLink>}

            {isLoggedIn && <NavLink to="/favorites" className='brand dark:text-purple-400'>Favorites</NavLink>}

            {isLoggedIn && (
                <button
                    onClick={() => {
                        logout();
                        navigate("/login");
                    }}
                    className='dark:text-purple-400'
                >
                    Logout
                </button>
            )}
        </footer>
    )
}

export default Footer