import { BarLoader, CircleLoader, RingLoader } from 'react-spinners';
import './Spinners.scss';

const Spinners = () => {
    return (
        <div>
            <BarLoader color="#0d0" />
            <CircleLoader color="#0d0" />
            <RingLoader color="#0d0" />
        </div>
    );
};

export default Spinners;