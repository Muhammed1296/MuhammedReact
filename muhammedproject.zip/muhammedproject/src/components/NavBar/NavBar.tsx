import { TextField } from '@mui/material';
import DarkLight from '../DarkLightMode/DarkLight';
import './NavBar.scss'
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import Search from '../Search/Search';


const NavBar = () => {
    const { isLoggedIn, user, logout } = useAuth();
    const navigate = useNavigate();

    return (
        <nav className='allNavBar'>
            <div className='nav-left'>
                <NavLink to='/' className='brand dark:text-purple-400'>Home</NavLink>
                <NavLink to='/about' className='brand dark:text-purple-400'>About</NavLink>

                {!isLoggedIn && <NavLink to='/register' className='brand dark:text-purple-400'>Register</NavLink>}

                {!isLoggedIn && <NavLink to='/login' className='brand dark:text-purple-400'>Login</NavLink>}

                {/* {isLoggedIn && <NavLink to='/profile' className='brand dark:text-purple-400'>Profile</NavLink>} */}

                {isLoggedIn && <NavLink to="/favorites" className='brand dark:text-purple-400'>Favorites</NavLink>}

                {isLoggedIn && user?.isBusiness &&
                    <NavLink to="/createCard" className='dark:text-purple-400'>Create Card</NavLink>}

                {isLoggedIn && user?.isBusiness &&
                    <NavLink to="/mycards" className='dark:text-purple-400'>My cards</NavLink>}

                {isLoggedIn && (
                    <button
                        onClick={() => {
                            logout();
                            navigate("/login");
                        }}
                        className='dark:text-purple-400'
                    >
                        Logout
                    </button>
                )}

                {/* {isLoggedIn && (<span>{user?.name.first}</span>)} */}

            </div>

            <div className='nav-right'>
                <Search />
                <DarkLight />

            </div>
        </nav>
    )
}

export default NavBar;