import { useTheme } from "../../hooks/useTheme";
import styles from './DarkLight.module.scss';
import { FaMoon, FaSun } from 'react-icons/fa';


const DarkLight = () => {
    const { theme, toggle } = useTheme();

    return (
        <button className={`${styles.toggle} ${styles[theme]}`} onClick={toggle}>
            {theme === "light" ? <FaMoon /> : <FaSun />}
        </button>
    );
};
export default DarkLight;