import React from 'react'
import './About.scss'

const About = () => {
    return (
        <div className='aboutP'>
            <h2>About</h2>
            <hr />
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus tenetur laboriosam natus perferendis. Dolorum, alias quisquam deleniti eius sint quos, omnis molestias illum numquam sit repellendus laudantium et ab at voluptatibus voluptas? Cupiditate inventore distinctio atque, vero, nobis sunt minima ipsam debitis id, nulla sed minus? Magnam, quasi alias aliquid voluptate porro facere nesciunt minus? Iste enim nesciunt, modi vitae consequatur dicta eveniet repellat, eum libero fugiat nam dolorum tempore doloremque in magni quos? Eveniet ipsum vitae iste dicta laudantium, doloribus commodi illo, itaque delectus culpa esse incidunt quaerat ab nihil porro necessitatibus cupiditate nisi adipisci! Vitae exercitationem labore eaque! Lorem ipsum dolor, sit amet consectetur adipisicing elit. Maxime reprehenderit sunt in id, quia aspernatur quidem? Aut sequi possimus dolorem, distinctio alias fugiat debitis animi libero illo ratione voluptatum totam!</div>
    )
}

export default About