import { Stack, TextField } from '@mui/material';
import './Search.scss';
import { useEffect, useState } from 'react';
import { CardType } from '../../@Types/types';
import { Link } from 'react-router-dom';
import { FaPhone } from 'react-icons/fa';
import axios from 'axios';
import { useCardContext } from '../../contexts/CardContext';
import { useSearch } from '../../contexts/SearchContext';

const Search = () => {
    const { setSearchTerm } = useSearch();

    return (

        <input
            className="searchBar" placeholder='Search here'
            onChange={(e) => {
                setSearchTerm(e.currentTarget.value);
            }}

        />

    )
}

export default Search