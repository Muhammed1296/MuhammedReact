import Swal from "sweetalert2";

export const showSuccessD = (title: string, text: string) => {
    return Swal.fire({ title, text, icon: 'success' });
};

export const showErrorD = (title: string, text: string) => {
    return Swal.fire({ title, text, icon: 'error' });
};

const dialogs = { success: showSuccessD, error: showErrorD };
export default dialogs;