import React from 'react'
import ReactDOM from 'react-dom/client'
import { ThemeProvider } from './contexts/ThemeContext.tsx'
import { RouterProvider } from 'react-router-dom'
import { router } from './routes/router.tsx'
import { AuthContextProvider } from './contexts/AuthContext.tsx'
import './index.css';
import { SearchProvider } from './contexts/SearchContext.tsx'
import { CardProvider } from './contexts/CardContext.tsx'
import axios from 'axios'

axios.interceptors.request.use((ans) => {
  const token = localStorage.getItem('token');
  if (token)
    ans.headers['x-auth-token'] = token;
  return ans;
})

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <AuthContextProvider>
      <ThemeProvider>
        <SearchProvider>
          <CardProvider>
            <RouterProvider router={router} />
          </CardProvider>
        </SearchProvider>
      </ThemeProvider>
    </AuthContextProvider>
  </React.StrictMode>
);
